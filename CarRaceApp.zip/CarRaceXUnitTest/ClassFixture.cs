﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarRaceXUnitTest
{
    public class ClassFixture : IDisposable
    {
        public ClassFixture()
        {

        }
        public void Dispose()
        {
            
        }
    }
}
